package tp.pr3.instructions;

import tp.pr3.NavigationModule;
import tp.pr3.RobotEngine;
import tp.pr3.instructions.exceptions.InstructionExecutionException;
import tp.pr3.instructions.exceptions.WrongInstructionFormatException;
import tp.pr3.items.ItemContainer;

public class ScanInstruction implements Instruction {
	private ItemContainer container;

	public ScanInstruction (){
		this.container = new ItemContainer();
	}
	
	public void configureContext(RobotEngine engine,
			NavigationModule navigation, ItemContainer robotContainer) {
		// TODO Auto-generated method stub
		this.container = robotContainer;
		
	}

	@Override
	public void execute() 
			throws InstructionExecutionException {
		// TODO Auto-generated method stub
		this.container.toString();
		
	}

	@Override
	public String getHelp() {
		// TODO Auto-generated method stub
		return "SCAN|ESCANEAR [id]";
	}

	@Override
	public Instruction parse(String cad) 
			throws WrongInstructionFormatException {
		// TODO Auto-generated method stub
		String [] cadena = cad.split(" ");
		
		if( !cadena[0].equalsIgnoreCase("SCAN") || !cadena[0].equalsIgnoreCase("ESCANEAR")){
				throw new WrongInstructionFormatException();
			}
		else{
			if ( cadena.length >1 &&  !this.container.existsItem(cadena[1])){
				throw new WrongInstructionFormatException();
		}
		return this;
	}
	}
}
