package tp.pr3;

public enum Rotation {
	LEFT, RIGHT, UNKNOWN
}
