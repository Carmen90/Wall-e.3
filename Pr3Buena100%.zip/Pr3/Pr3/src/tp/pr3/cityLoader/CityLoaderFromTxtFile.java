package tp.pr3.cityLoader;


import java.util.ArrayList;
import java.util.Scanner;

import tp.pr3.City;
import tp.pr3.Direction;
import tp.pr3.Place;
import tp.pr3.Street;
import tp.pr3.cityLoaderExceptions.WrongCityFormatException;
import tp.pr3.items.CodeCard;
import tp.pr3.items.Fuel;
import tp.pr3.items.Garbage;

	public class CityLoaderFromTxtFile {
		private ArrayList<Place> place;
		private ArrayList <Street> street;
		
	public 	CityLoaderFromTxtFile (){
		this.place = new ArrayList <Place> ();
		this.street = new ArrayList<Street> ();
	}
	
	public City loadCity(java.io.InputStream file)
            throws java.io.IOException, WrongCityFormatException{
		
		Scanner entrada = new Scanner (file);
		String resp = entrada.next(); 
		
		if ( resp.equalsIgnoreCase("BeginCity")){
				while ( !resp.equalsIgnoreCase("EndCity")){
					resp = entrada.next();
					if ( resp.equalsIgnoreCase("BeginPlaces")){
						creaPlaces (resp, entrada);

					}
					else if ( resp.equalsIgnoreCase("BeginStreets")){
						creaStreets ( resp, entrada);
								
					}
					else if ( resp.equalsIgnoreCase("BeginItems")){
								
					}
					else{
						throw new WrongCityFormatException();
					}
				}
		}
						
		return null;
	}

	public Place getInitialPlace (){
		return this.place.get(0);
	}
	
	public void creaPlaces ( String resp, Scanner entrada)
			throws WrongCityFormatException{
		int num = 0;
		String descripcion = null;
		String nombre = null;
		
		while ( !resp.equalsIgnoreCase("EndPlaces") ){
			resp = controlNext(entrada);
				if ( resp.equalsIgnoreCase("place")){
					num = controlNextInt(entrada);
					nombre = controlNext(entrada);
					descripcion = controlNext (entrada);
					resp = controlNext( entrada);
						if ( resp.equalsIgnoreCase("noSpaceShip")){
							///////////Pasar descripcion a formato correcto///////////////////////////////
							this.place.set(num, new Place (nombre, false, descripcion));
						}
						else if ( resp.equalsIgnoreCase("spaceShip")){
							///////////Pasar descripcion a formato correcto///////////////////////////////
							this.place.set(num , new Place (nombre, true, descripcion));
						}
						else{
							throw new WrongCityFormatException();
						}
			}
			else{
				throw new WrongCityFormatException();
			}
		}
	}

	public void creaStreets ( String resp, Scanner entrada)
			throws WrongCityFormatException{
		
		int num = 0;
		int numPlaceIni = 0;
		int numPlaceFin = 0;
		Direction direccion = null;
		
		while ( !resp.equalsIgnoreCase("EndStreets") ){
			resp = entrada.next();
				if ( resp.equalsIgnoreCase("street")){
					num = controlNextInt(entrada);
					resp = controlNext (entrada);
						if (resp.equalsIgnoreCase("place")){
							
							numPlaceIni = controlNextInt(entrada);
							resp = controlNext (entrada);
							direccion = Direction.valueOf(resp);
							resp = controlNext (entrada);
							
							if( resp.equalsIgnoreCase("place")){
								
								numPlaceFin = controlNextInt (entrada);
								resp = controlNext (entrada);
								
								if ( resp.equalsIgnoreCase("open")){
									this.street.set(num, new Street (this.place.get(numPlaceIni), direccion, this.place.get(numPlaceFin)));
								}
								else if (resp.equalsIgnoreCase("closed")){
									resp = controlNext (entrada);
									this.street.set(num, new Street (this.place.get(numPlaceIni), direccion, this.place.get(numPlaceFin), false, resp));
									
								}
								else{
									throw new WrongCityFormatException();
								}
							}else{
								throw new WrongCityFormatException();
							}
						}else{
							throw new WrongCityFormatException();
						}
				}
		}
	}

	public void creaItems ( String resp, Scanner entrada)
			throws WrongCityFormatException{
		//int num = 0;
		String descripcion = null;
		String nombre = null;
		int numPlace = 0;
		int power = 0;
		int cantidad = 0;
		String code = null;
		
		while ( !resp.equalsIgnoreCase("EndItems")){
			resp = controlNext(entrada);
			
			if ( resp.equalsIgnoreCase("fuel")){
				//num = controlNextInt (entrada);
				controlNextInt (entrada);
				nombre = controlNext (entrada);
				descripcion = controlNext ( entrada);
				power = controlNextInt ( entrada);
				cantidad = controlNextInt (entrada);
				resp = controlNext (entrada);
				if (resp.equalsIgnoreCase("place")){
					numPlace = controlNextInt (entrada);
					this.place.get(numPlace).addItem(new Fuel (nombre, descripcion, power, cantidad));
				}
				
			}
			else if (resp.equalsIgnoreCase("codecard")){
				controlNextInt (entrada);
				nombre = controlNext (entrada);
				descripcion = controlNext ( entrada);
				code = controlNext ( entrada);
				cantidad = controlNextInt (entrada);
				resp = controlNext (entrada);
				if (resp.equalsIgnoreCase("place")){
					numPlace = controlNextInt (entrada);
					this.place.get(numPlace).addItem(new CodeCard (nombre, descripcion, code));
				}
				
			}
			else if (resp.equalsIgnoreCase("garbage")){
				controlNextInt (entrada);
				nombre = controlNext (entrada);
				descripcion = controlNext ( entrada);
				cantidad = controlNextInt (entrada);
				resp = controlNext (entrada);
				if (resp.equalsIgnoreCase("place")){
					numPlace = controlNextInt (entrada);
					this.place.get(numPlace).addItem(new Garbage (nombre, descripcion, cantidad));
				}
			}
			else{
				throw new WrongCityFormatException();
			}
		}
	}
 	public String controlNext ( Scanner entrada) 
			throws WrongCityFormatException{
		String resp = null;
		if (entrada.hasNext()){
			resp = entrada.next();
		} else{
			throw new WrongCityFormatException();
		}
		return resp;
	}
	
	public int controlNextInt ( Scanner entrada) 
			throws WrongCityFormatException{
		String resp = null;
		int numero = 0;
		
		if (entrada.hasNext()){
			resp = entrada.next();
			numero = Integer.parseInt(resp);
		} else{
			throw new WrongCityFormatException();
		}
		return numero;
	}
}

