package tp.pr3;
import java.util.Scanner;

import tp.pr3.instructions.Instruction;
import tp.pr3.instructions.QuitInstruction;
import tp.pr3.instructions.exceptions.InstructionExecutionException;
import tp.pr3.instructions.exceptions.WrongInstructionFormatException;
import tp.pr3.items.ItemContainer;
public class RobotEngine {
	private ItemContainer container;
	private Instruction instruction;
	private NavigationModule navega;
	private int power;
	private int reciclado;
	private static 	Scanner leer = new Scanner(System.in);
	String LINE_SEPARATOR = System.getProperty("line.separator");
	
	//////Metodos a implementar segun la documentaci�n/////
	public RobotEngine (){
		this.navega = new NavigationModule ();
		this.power = 50;
		this.reciclado = 0;
		this.container = new ItemContainer ();
		this.instruction = null;
	}
	
	public RobotEngine ( Place initialPlace, Direction direction,City cityMap ){
		this.navega = new NavigationModule ( cityMap, initialPlace);
		this.power = 50;
		this.reciclado = 0;
		this.container = new ItemContainer ();
		this.instruction = null;
	}
	
	public RobotEngine(City cityMap, Place initialPlace, Direction direction){
		this.navega = new NavigationModule ( cityMap, initialPlace);
		this.power = 50;
		this.reciclado = 0;
		this.container = null;
	}
	
	public void addFuel(int fuel){
		this.power += fuel;
		if(this.power<0){
			this.power=0;
		}
	}
	
	public void addRecycledMaterial(int weight){
		this.reciclado += weight;		
	}
	
	/////////////////////////////////////////////////////////////////////////////////
	/*Implementar printRobotState, requestQuit*/
	//IMPLEMENTAR/////////////////////////////////////////////////////////////////////
	public void communicateRobot(Instruction c){
		c.configureContext(this, this.navega, this.container);
		try {
			c.execute();
		} catch (InstructionExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void requestHelp(){
		System.out.println ( Interpreter.interpreterHelp());
	}

	public void printRobotState(){
		
	}
	
	public void startEngine(){
		String linea;
		String LINE_SEPARATOR = System.getProperty("line.separator");
		
		
		System.out.println(this.navega.getInitialPlace().toString()+ LINE_SEPARATOR + "   * My power is " + power+ LINE_SEPARATOR + "   * My recycled material is: " + reciclado 
				+ LINE_SEPARATOR + "WALL·E is looking at direction "+ this.navega.getCurrentHeading() ); // Primer punto
		
		System.out.print("WALL·E > ");
		linea = leer.nextLine();
		try {
			this.instruction = Interpreter.generateInstruction ( linea);
			this.communicateRobot(instruction);
		} catch (WrongInstructionFormatException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		while ( this.instruction.getClass() != QuitInstruction.class && !this.navega.getInitialPlace().isSpaceship() && this.power > 0 ){ //Segundo punto
		 // Punto 2b
			System.out.print("WALL·E > ");
			linea = leer.nextLine();
			
			//////////////MIRAR SI HAY QUE CAPTURAR EXCEPTION O LANZARLA///////////
			this.communicateRobot(instruction);
			try {
				this.instruction = Interpreter.generateInstruction ( linea);
			} catch (WrongInstructionFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 		
			
		if (this.navega.getInitialPlace().isSpaceship()){
			System.out.println ( "WALL·E says: I am at my space ship. Bye Bye");
		}	
		if ( power == 0){
			System.out.println ("WALL·E says: I run out of fuel. I cannot move. Shutting down...");
		}
	}
	}

	
	/////M�todos propios/////
	public int getRecycledMaterial(){
		return this.reciclado;
	}

	public void setReciclado( int reciclado) {
		// TODO Auto-generated method stub
		this.reciclado = reciclado;
		
	}
	
	public int getPower() {
		return this.power;
	}
	


}
