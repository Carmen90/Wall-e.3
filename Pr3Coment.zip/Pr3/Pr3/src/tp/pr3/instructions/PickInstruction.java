package tp.pr3.instructions;

import tp.pr3.NavigationModule;
import tp.pr3.RobotEngine;
import tp.pr3.instructions.exceptions.InstructionExecutionException;
import tp.pr3.instructions.exceptions.WrongInstructionFormatException;
import tp.pr3.items.ItemContainer;

public class PickInstruction implements Instruction{
	private NavigationModule navega;
	private String id;
	
	public PickInstruction (){
		this.id = " ";
		this.navega = new NavigationModule ();
	}
	
	public void configureContext(RobotEngine engine,
			NavigationModule navigation, ItemContainer robotContainer) {
		// TODO Auto-generated method stub
		
		this.navega = navigation;
	}

	
	public void execute() 
			throws InstructionExecutionException {
		// TODO Auto-generated method stub
		this.navega.pickItemFromCurrentPlace(id);
		
	}


	public String getHelp() {
		// TODO Auto-generated method stub
		return "PICK|COGER <id>";
	}

	
	public Instruction parse(String cad) 
			throws WrongInstructionFormatException {
		// TODO Auto-generated method stub
		
		String []cadena = cad.split(" ");
		if ( !cadena [0].equalsIgnoreCase("PICK") || !cadena[0].equalsIgnoreCase("COGER") || !this.navega.getInitialPlace().existItem(cadena[1])
				|| cadena.length > 2){
			throw new WrongInstructionFormatException();
		}
		this.id = cadena [1];
		return this;
	}

}
